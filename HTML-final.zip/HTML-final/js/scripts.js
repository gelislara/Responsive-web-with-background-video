$(function(){
	window.addEventListener('scroll', function(e){
		var distanceY = window.pageYOffset || document.documentElement.scrollTop,
            shrinkOn = 5;
		if (distanceY > shrinkOn) {
            $("nav").addClass("blanco");
            $(".fondoClaro").addClass("gone");
        } else {
            if ($("nav").hasClass("blanco")) {
                $("nav").removeClass("blanco");
                $(".fondoClaro").removeClass("gone");
            }
        }
	});	
    
    $('a[href*=#]:not([href=#])').click(function() {
        if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000);
                return false;
            }
        }
    });
    
    var heightPage = $(window).height();
    var widthPage = $(window).width();
    var heightFondo = $(".fondoClaro .container").height();
    var numPadding = (heightPage - heightFondo)/2;
    var numLeft = (widthPage/2)-25;
    
    if(widthPage > 992){
        numPadding = numPadding + 25;
    }else if(widthPage > 280 && widthPage < 580){
        numPadding = numPadding + 25;
    }
    
    $(".fondoClaro").css("padding",numPadding+"px 0px");
    $(".center").css("left",numLeft+"px");
    
    //alert(heightPage+", "+height2);
    
});