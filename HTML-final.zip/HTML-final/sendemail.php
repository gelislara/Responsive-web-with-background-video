<?php
    $email_message = "Detalles del formulario de contacto:\n\n";
    $email_message .= "Nombre: " . $_POST['nombre'] . "\n";
    $email_message .= "E-mail: " . $_POST['email'] . "\n";
    $email_message .= "Asunto: " . $_POST['asunto'] . "\n";
    $email_message .= "Comentarios: " . $_POST['comentario'] . "\n\n";

    $email_from = $_POST['email'];
    $email_to = "contacto@viadigital389.com";
    $email_subject = "Contacto desde el sitio web - ".$_POST['asunto'];

// Ahora se envía el e-mail usando la función mail() de PHP
    $headers = 'From: '.$email_from."\r\n".
        'Reply-To: '.$email_from."\r\n" .
        'X-Mailer: PHP/' . phpversion();
    if(mail($email_to, $email_subject, $email_message, $headers))
    {
        ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Agencia de mercadotecnia digital especializada en manejo de redes sociales, Google AdWords, Facebook Ads, desarrollo web y email marketing.">
    <meta name="keywords" content="Comunicación, Diseño Web, comunicólogos, mercadotecnia, Agencia de mercadotecnia, mercadotencia digital, mercadólogos, desarrollo web, redes sociales, facebook ads, google adwords, email marketing, marketing, via digital 389, vía digital 389, 389, via digital, vía digital, vd 389">
    <meta name="author" content="Vía Digital 389">
    <title>VÍA DIGITAL 389</title>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <link href="css/vd389.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
</head>

<body id="retro" itemscope itemtype="http://schema.org/Organization">

<header>
    <nav class="navbar navbar-default navbar-fixed-top navbar-vd" role="navigation">
        <div class="container">
            <div class="navbar-header" itemscope itemtype="https://schema.org/Brand">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Navegación</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="/" itemprop="logo"><img src="img/logo.png" alt="Vía Digital 389" /></a>
				</div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a class="nav-morado" href="conocenos ">Conócenos</a></li>
                    <li><a class="nav-naranja" href="redessociales ">Redes Sociales</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle nav-verde" data-toggle="dropdown">Campañas<span class="caret"></span></a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="facebookads ">Facebook Ads</a></li>
                            <li><a href="googleadwords ">Google Adwords</a></li>
                            <li><a href="emailmarketing ">Email Marketing</a></li>
                        </ul>
                    </li>
                    <li><a class="nav-azul" href="desarrolloweb ">Desarrollo Web</a></li>
                    <li class="active"><a class="nav-morado" href="contacto ">Contacto</a></li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
</header>

<div class="fondoAzul">
    <div class="container">
        <h2>Tu mensaje ha sido enviado con éxito. Nosotros nos pondremos en contacto contigo.</h2>
    </div>
</div>

<div class="tiraColores"></div>

<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 seccion">
                <img class="logo" src="img/logo.png" />
                <ul>
                    <li><a href="conocenos ">Conócenos</a></li>
                    <li><a href="redessociales ">Redes Sociales</a></li>
                    <li><a href="campanias ">Campañas</a></li>
                    <li><a href="desarrolloweb ">Desarrollo Web</a></li>
                </ul>
            </div>
            <div class="socialicons col-sm-4 seccion">
                <h4>Conoce las nuevas tendencias</h4>
                <div>
                    <a target="_blank" href="https://www.facebook.com/viadigital389" class="icon-face"></a>
                    <a target="_blank" href="https://plus.google.com/114296727398363481105/posts" class="icon-gplus"></a>
                    <a target="_blank" href="https://twitter.com/Viadigital389" class="icon-twt"></a>
                    <a target="_blank" href="https://www.linkedin.com/company/vía-digital-389/" class="icon-li"></a>
                    <a target="_blank" href="http://instagram.com/viadigital389" class="icon-inst"></a>
                    <a target="_blank" href="http://www.pinterest.com/viadigital389/" class="icon-pint"></a>
                </div>
            </div>
            <div class="col-sm-4 phone seccion">
                      <div itemprop="telephone"><a href="tel:+52818110446464">+52 (81) 811 044 64 64</a> <img src="img/phone.png" /></div>
                      <div itemprop="email">contacto@viadigital389.com <img src="img/email.png" /></div>
                  </div>
        </div>
    </div>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>

<?php
    } else {
        ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Agencia de mercadotecnia digital especializada en manejo de redes sociales, Google AdWords, Facebook Ads, desarrollo web y email marketing.">
    <meta name="keywords" content="Comunicación, Diseño Web, comunicólogos, mercadotecnia, Agencia de mercadotecnia, mercadotencia digital, mercadólogos, desarrollo web, redes sociales, facebook ads, google adwords, email marketing, marketing, via digital 389, vía digital 389, 389, via digital, vía digital, vd 389">
    <meta name="author" content="Vía Digital 389">
    <title>VÍA DIGITAL 389</title>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <link href="css/vd389.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
</head>

<body id="retro" itemscope itemtype="http://schema.org/Organization">

<header>
    <nav class="navbar navbar-default navbar-fixed-top navbar-vd" role="navigation">
        <div class="container">
            <div class="navbar-header" itemscope itemtype="https://schema.org/Brand">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Navegación</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index " itemprop="logo"><img src="img/logo.png" alt="Vía Digital 389" /></a>
				</div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a class="nav-morado" href="conocenos ">Conócenos</a></li>
                    <li><a class="nav-naranja" href="redessociales ">Redes Sociales</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle nav-verde" data-toggle="dropdown">Campañas<span class="caret"></span></a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="facebookads ">Facebook Ads</a></li>
                            <li><a href="googleadwords ">Google Adwords</a></li>
                            <li><a href="emailmarketing ">Email Marketing</a></li>
                        </ul>
                    </li>
                    <li><a class="nav-azul" href="desarrolloweb ">Desarrollo Web</a></li>
                    <li class="active"><a class="nav-morado" href="contacto ">Contacto</a></li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
</header>

<div class="fondoAzul">
    <div class="container">
        <h4>Tu mensaje no se ha podido enviar en estos momentos. Por favor intenta más tarde o contáctanos a nuestro correo contacto@viadigital389.com o a nuestro teléfono +52 (81) 811 044 64 64</h4>
    </div>
</div>

<div class="tiraColores"></div>

<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 seccion">
                <img class="logo" src="img/logo.png" />
                <ul>
                    <li><a href="conocenos ">Conócenos</a></li>
                    <li><a href="redessociales ">Redes Sociales</a></li>
                    <li><a href="campanias ">Campañas</a></li>
                    <li><a href="desarrolloweb ">Desarrollo Web</a></li>
                </ul>
            </div>
            <div class="socialicons col-sm-4 seccion">
                <h4>Conoce las nuevas tendencias</h4>
                <div>
                    <a target="_blank" href="https://www.facebook.com/viadigital389" class="icon-face"></a>
                    <a target="_blank" href="https://plus.google.com/114296727398363481105/posts" class="icon-gplus"></a>
                    <a target="_blank" href="https://twitter.com/Viadigital389" class="icon-twt"></a>
                    <a target="_blank" href="https://www.linkedin.com/company/vía-digital-389/" class="icon-li"></a>
                    <a target="_blank" href="http://instagram.com/viadigital389" class="icon-inst"></a>
                    <a target="_blank" href="http://www.pinterest.com/viadigital389/" class="icon-pint"></a>
                </div>
            </div>
            <div class="col-sm-4 phone seccion">
                      <div itemprop="telephone"><a href="tel:+52818110446464">+52 (81) 811 044 64 64</a> <img src="img/phone.png" /></div>
                      <div itemprop="email">contacto@viadigital389.com <img src="img/email.png" /></div>
                  </div>
        </div>
    </div>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>

    
<?php
    }
?>